var searchData=
[
  ['vertices_0',['vertices',['../struct_d_c_e_l.html#ade0e662c344e8b99fd3276c1694439f3',1,'DCEL']]]
];
