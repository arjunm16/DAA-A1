var searchData=
[
  ['dcel_0',['DCEL',['../struct_d_c_e_l.html',1,'']]]
];
