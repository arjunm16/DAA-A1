/*
Group Details

|       Name                |          ID                |
|---------------------------|---------------------------|
| Harsh Vardhan Gupta         |     2019B3A70630H         |
| Aryan Kapadia             |     2019B3A70412H         |
| Arjun Muthiah              |     2019B3A70374H         |
*/
#include<bits/stdc++.h>
#define pb push_back
using namespace std;

struct HalfEdge;

/// @brief Vertex for DCEL
struct Vertex{
    Vertex(){};
    Vertex(const Vertex &v1);    
    double x; ///< X-coordinate of Vertex
    double y; ///< Y-coordinate of Vertex
    int key;///< Key of Vertex
    vector<HalfEdge*> incidentEdges; ///< Vector of pointers to incidentEgdes on the Vertex
    Vertex* next; ///< Pointer to the next Vertex in Clockwise Order
};
/// @brief Face for DCEL
struct Face{
    Face(){};
    Face(const Face &f1);
    HalfEdge* edge;  ///< pointer to a single HalfEdge Corresponding to Face
};
/// @brief HalfEdge for DCEL
struct HalfEdge{
    HalfEdge(){};
    HalfEdge(const HalfEdge &hf);
    Vertex *origin; ///< Origin Vertex of HalfEdge
    HalfEdge* twin = NULL; ///< pointer to Twin HalfEdge for the Corresponding Edge
    HalfEdge* next = NULL; ///< pointer to Next HalfEdge for the Corresponding Edge
    HalfEdge* prev = NULL; ///< pointer to Previous HalfEdge for the Corresponding Edge
    Face* face = NULL; /// < pointer to Face Corresponding to HalfEdge
    int origin_vkey; ///< Key for the origin Vertex of HalfEdge
};

Vertex::Vertex(const Vertex &v1){
        for(int i = 0; i<v1.incidentEdges.size(); i++){
            HalfEdge *temp = new HalfEdge;
            *temp = *v1.incidentEdges[i];
            incidentEdges.pb(temp);
        }
        double *temp = new double;
        *temp = v1.x; 
        x = *temp;

        temp = new double;
        *temp = v1.y; 
        y = *temp;

        int *temp1 = new int;
        *temp1 = v1.key;
        // *incidentEdges = v1.incidentEdges;
        key = *temp1;
    }

HalfEdge::HalfEdge(const HalfEdge &hf){
        origin = new Vertex;
        *origin = *(hf.origin);
        twin = new HalfEdge;
        *twin = *(hf.twin);
        next = new HalfEdge;
        *next = *hf.next;
        prev = new HalfEdge;
        *prev = *hf.prev;
        face = new Face;
        *face = *hf.face;
        // origin_vkey = new int;
        origin_vkey = hf.origin_vkey;
    }

Face::Face(const Face &f1){
        edge = new HalfEdge;
        *edge = *f1.edge;
    }

/// @brief DCEL 
struct DCEL{
    DCEL(){};
    DCEL(const DCEL &d){
        for(int i = 0; i < d.vertices.size(); i++){
            Vertex *temp = new Vertex;
            *temp = *d.vertices[i];
            vertices.pb(temp);
        }

        for(int i = 0; i < d.halfEdges.size(); i++){
            HalfEdge *temp = new HalfEdge;
            *temp = *d.halfEdges[i];
            halfEdges.pb(temp);
        }

        for(int i = 0; i < d.faces.size(); i++){
            Face *temp = new Face;
            *temp = *d.faces[i];
            faces.pb(temp);
        }
    }
    vector<Vertex*> vertices; ///< Vector of pointers to vertices in DCEL
    vector<HalfEdge*> halfEdges; ///< Vector of pointers to HalfEgdes in DCEL
    vector<Face*> faces; ///< Vector of pointers to Faces in DCEL
    vector<HalfEdge*> diags; ///< Vector of pointers to diagonals in DCEL
};
