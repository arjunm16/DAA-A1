var searchData=
[
  ['next_0',['next',['../struct_vertex.html#afc0e463d7fee2693916ee645d8a75f86',1,'Vertex::next()'],['../struct_half_edge.html#a5918db069bb8b4a89e471c01a14fc6e1',1,'HalfEdge::next()']]]
];
