var struct_face =
[
    [ "Face", "struct_face.html#afdb634bc2d5287ba0d62e46b57e9dc2e", null ],
    [ "Face", "struct_face.html#a6a1d988e317e4572c977c223f5cf9579", null ],
    [ "edge", "struct_face.html#a92c80d451252fe71136aaef224f1853b", null ]
];