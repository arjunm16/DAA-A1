var searchData=
[
  ['origin_0',['origin',['../struct_half_edge.html#a8c90288f66768884f42b0588055eb4bf',1,'HalfEdge']]],
  ['origin_5fvkey_1',['origin_vkey',['../struct_half_edge.html#a810f625e70e63861faa13ebdd7eac8a9',1,'HalfEdge']]]
];
