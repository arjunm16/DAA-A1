var searchData=
[
  ['key_0',['key',['../struct_vertex.html#a71cf20b05f7b3aee13814795c331f1a8',1,'Vertex']]]
];
