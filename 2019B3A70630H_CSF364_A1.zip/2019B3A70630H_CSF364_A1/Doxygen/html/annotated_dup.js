var annotated_dup =
[
    [ "DCEL", "struct_d_c_e_l.html", "struct_d_c_e_l" ],
    [ "Face", "struct_face.html", "struct_face" ],
    [ "HalfEdge", "struct_half_edge.html", "struct_half_edge" ],
    [ "Vertex", "struct_vertex.html", "struct_vertex" ]
];