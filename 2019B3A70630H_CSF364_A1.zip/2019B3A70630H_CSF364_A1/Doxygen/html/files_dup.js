var files_dup =
[
    [ "dcel_hvg.hpp", "dcel__hvg_8hpp.html", "dcel__hvg_8hpp" ],
    [ "htester_final_1.cpp", "htester__final__1_8cpp.html", "htester__final__1_8cpp" ]
];