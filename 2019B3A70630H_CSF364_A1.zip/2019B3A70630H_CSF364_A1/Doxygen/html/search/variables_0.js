var searchData=
[
  ['diags_0',['diags',['../struct_d_c_e_l.html#af6bfc7e4a6c31286448fb964f281e41c',1,'DCEL']]]
];
