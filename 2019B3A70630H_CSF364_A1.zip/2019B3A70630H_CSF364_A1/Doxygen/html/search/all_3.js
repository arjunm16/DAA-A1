var searchData=
[
  ['edge_0',['edge',['../struct_face.html#a92c80d451252fe71136aaef224f1853b',1,'Face']]]
];
