var searchData=
[
  ['face_0',['Face',['../struct_face.html#afdb634bc2d5287ba0d62e46b57e9dc2e',1,'Face::Face()'],['../struct_face.html#a6a1d988e317e4572c977c223f5cf9579',1,'Face::Face(const Face &amp;f1)']]],
  ['findnotches_1',['findNotches',['../htester__final__1_8cpp.html#abb622862625d0bff5e09bd813df9855e',1,'htester_final_1.cpp']]]
];
