var searchData=
[
  ['face_0',['face',['../struct_half_edge.html#a08080cb14f0da4274e47a56f24071196',1,'HalfEdge']]],
  ['faces_1',['faces',['../struct_d_c_e_l.html#a2d7fd9417422b18f18e8c55f1d1f49e2',1,'DCEL']]]
];
